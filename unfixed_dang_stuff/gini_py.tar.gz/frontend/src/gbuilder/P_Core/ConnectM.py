class ConnectM ():
	def __init__(self):
		self.IP=''
		self.Name=''
		self.mac=''
		self.port=''




