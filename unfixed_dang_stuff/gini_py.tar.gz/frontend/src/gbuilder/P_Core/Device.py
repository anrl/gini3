"""The logical object of a node"""

from UI.Node import *

class Device(Node):

    def __init__(self):
        """
        Create a logical side to the node.
        """
        Node.__init__(self)
        self.connection = []

#class ConnectM():
#   def __init__(self):
#		self.IP=''
#		self.Name=''
#		self.Mac=''
#		self.Port=''
#   def __new__(self,name,ip,mac,port):
#	self.IP=ip
#	self.Name=name
#	self.Mac=mac
#	self.

#class Mpacket():
#    def __init__(self,number):
#	self.realMnumber=number
#	self.data=ConnectM[number]
#   def setmember(i,member)
#	self,data[i]=member
  
   

	
