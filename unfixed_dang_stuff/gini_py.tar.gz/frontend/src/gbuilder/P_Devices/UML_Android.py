from UML import *

class UML_Android(UML):
    type="UML_Android"

