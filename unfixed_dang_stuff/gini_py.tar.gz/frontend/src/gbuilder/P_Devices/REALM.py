from Core.Connection import *
from Core.Interfaceable import *
from Core.globals import environ
from PyQt4.QtCore import QPoint

class REALM(Interfaceable):
    type="REALM"


    def __init__(self):

        Interfaceable.__init__(self)

        self.setProperty("realmachineIPv4", "")
        self.setProperty("realmachinePort", "")
 	self.setProperty("realmachineMac", "")
	self.setProperty("filetype", "cow")
        self.setProperty("filesystem", "root_fs_beta2")
	self.hostIndex = 0
        self.properties["Hosts"] = ["default","change"]
        self.hostsproperty={"default":ConnectM("1","2","3","4"),"change":ConnectM("name","ip","mac","port")}
        self.lightPoint = QPoint(-10,3)


class ConnectM():
    def __init__ (self,name,ip,mac,port):
	self.name=name
	self.ip=ip
	self.mac=mac
	self.port=port



