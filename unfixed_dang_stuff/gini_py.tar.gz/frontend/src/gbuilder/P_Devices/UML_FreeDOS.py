from UML import *

class UML_FreeDOS(UML):
    type="UML_FreeDOS"

