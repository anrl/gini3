datarev = "aaa"              # The receive data from server
